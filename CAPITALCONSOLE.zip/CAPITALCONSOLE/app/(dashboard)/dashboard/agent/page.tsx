import { ActivityFeed } from '@/components/dashboard/ActivityFeed';
import { KPIStatCard } from '@/components/dashboard/KPIStatCard';
import { PlayerCardFIFA } from '@/components/gamification/PlayerCardFIFA';
import { SkillBars } from '@/components/gamification/SkillBars';
import { dataClient } from '@/data/client';

export default function AgentDashboardPage() {
  const data = dataClient.dashboard();

  return (
    <div className="space-y-4 animate-slide-up">
      <section>
        <h2>Agent · Today</h2>
        <p className="text-sm text-slate-400">Appointments, conversion and revenue snapshot.</p>
      </section>

      <section className="grid gap-3 md:grid-cols-3">
        {data.kpis.map((kpi) => (
          <KPIStatCard key={kpi.label} label={kpi.label} value={kpi.value} />
        ))}
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        <ActivityFeed />
        <PlayerCardFIFA />
      </section>

      <SkillBars />
    </div>
  );
}
