export default function ContactsPage() {
  return <div className="glass-card p-6">Contacts screen placeholder</div>;
}
