export default function ManagerDashboardPage() {
  return <div className="glass-card p-6">Manager dashboard premium placeholder</div>;
}
