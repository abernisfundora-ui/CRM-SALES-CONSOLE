export default function PerformancePage() {
  return <div className="glass-card p-6">Performance screen placeholder</div>;
}
