export default function PipelinePage() {
  return <div className="glass-card p-6">Pipeline screen placeholder</div>;
}
