import { CandidateCard } from '@/components/recruiting/CandidateCard';
import { RecruitingPipeline } from '@/components/recruiting/RecruitingPipeline';

export default function RecruitingPage() {
  return (
    <div className="space-y-4 animate-slide-up">
      <section>
        <h2>Recruiting</h2>
        <p className="text-sm text-slate-400">Track candidates with a clear ATS-style flow.</p>
      </section>
      <RecruitingPipeline />
      <CandidateCard />
    </div>
  );
}
