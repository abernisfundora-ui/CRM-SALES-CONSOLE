export default function SalesPage() {
  return <div className="glass-card p-6">Sales screen placeholder</div>;
}
