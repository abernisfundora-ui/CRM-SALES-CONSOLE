export default function TrainingPage() {
  return <div className="glass-card p-6">Training screen placeholder</div>;
}
