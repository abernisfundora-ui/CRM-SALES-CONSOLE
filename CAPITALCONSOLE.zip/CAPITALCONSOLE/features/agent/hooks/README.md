# agent hooks
