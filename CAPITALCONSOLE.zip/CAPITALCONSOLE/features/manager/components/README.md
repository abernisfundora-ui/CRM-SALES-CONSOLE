# manager components
