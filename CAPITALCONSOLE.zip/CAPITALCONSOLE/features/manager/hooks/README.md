# manager hooks
