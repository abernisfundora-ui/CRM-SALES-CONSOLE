# manager schemas
