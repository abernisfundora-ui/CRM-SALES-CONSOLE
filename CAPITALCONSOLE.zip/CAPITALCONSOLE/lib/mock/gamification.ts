export const gamificationMock = [];
