export const pipelineMock = [];
