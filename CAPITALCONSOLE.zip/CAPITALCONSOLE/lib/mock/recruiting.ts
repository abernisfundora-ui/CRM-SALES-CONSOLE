export const recruitingMock = [];
