export const tenantsMock = [];
